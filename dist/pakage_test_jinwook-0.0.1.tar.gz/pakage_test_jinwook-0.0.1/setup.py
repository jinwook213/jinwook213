from setuptools import setup, find_packages
# https://wikidocs.net/78954
setup(
    name='pakage_test_jinwook',
    version='0.0.1',
    description='jinwook pakage test',
    url='https://github.com/jinwook213/jinwook213.git',
    author = 'Jinwook_Lee',
    long_description='test',
    author_email= 'jinwook213@cau.ac.kr',
    license = 'jinwook',
    packages = find_packages(),
    zip_safe= False,
    #install_requires = ['numpy==1.18.3']
    

)